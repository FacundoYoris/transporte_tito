-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: innway_ingenieria
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activos`
--

DROP TABLE IF EXISTS `activos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activos` (
  `idactivos` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `sector` varchar(45) DEFAULT NULL,
  `planta` varchar(45) DEFAULT NULL,
  `estado` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idactivos`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Maquinaria de la empresa';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activos`
--

LOCK TABLES `activos` WRITE;
/*!40000 ALTER TABLE `activos` DISABLE KEYS */;
INSERT INTO `activos` VALUES (5,'Grupo electrógeno','Generación de Energía para Emergencias','El Nato - Llambi Campbell','Disponible'),(6,'Otro activo de prueba','Generación de Energía para Emergencias','El Nato - Llambi Campbell','Disponible'),(7,'PC 1','Administrativo','El Nato - Llambi Campbell','Disponible');
/*!40000 ALTER TABLE `activos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden_trabajo`
--

DROP TABLE IF EXISTS `orden_trabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orden_trabajo` (
  `id_orden_trabajo` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(45) NOT NULL DEFAULT '"One shoot"',
  `actividad` varchar(200) DEFAULT '',
  `fecha_inicio` varchar(45) DEFAULT NULL,
  `activo` varchar(45) DEFAULT '',
  `responsable` varchar(45) DEFAULT '',
  `estado` varchar(45) DEFAULT 'Pendiente',
  `prioridad` varchar(45) DEFAULT 'Media',
  `usuario_creador` varchar(45) DEFAULT '',
  `descripción_problematica` varchar(200) DEFAULT '',
  `descripcion_solucion` varchar(200) DEFAULT '',
  `fecha_fin` varchar(45) DEFAULT NULL,
  `horas_totales` float DEFAULT NULL,
  `lapsoProgramada` decimal(10,0) NOT NULL,
  `fecha_inicio_real` varchar(45) DEFAULT NULL,
  `elemento` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_orden_trabajo`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Tabla que guarda todas las órdenes de trabajo.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_trabajo`
--

LOCK TABLES `orden_trabajo` WRITE;
/*!40000 ALTER TABLE `orden_trabajo` DISABLE KEYS */;
INSERT INTO `orden_trabajo` VALUES (113,'Correctiva','Corregir regulador de velocidad','2024-03-11T16:30','Otro activo de prueba','Facundo Yoris','Finalizada','Media','x','Disminuye tensión generada al aplicar carga y no retorna\r\n','Regulador de velocidad en estado óptimo.','2024-02-27T07:26',0.0136944,0,'2024-02-27T07:26','Limitador U/F'),(114,'Correctiva','Eliminar el bobinado auxiliar y hacer la conexión conforme a los diagramas de la página 17 del manual de instalación, operación y  mantenimiento del regulador','2024-02-22T23:35','Grupo electrógeno','Cesar Correia','En proceso','Media','FacundoYoris','Tensión oscila en un punto de carga especifico','',NULL,NULL,0,'2024-03-06T11:30','Tensión generada'),(115,'Correctiva','Verificar si las fases del alternador están presentes en la regeneración.','2024-03-01T20:30','Grupo electrógeno','Nahuel Nuñez','Finalizada','Alta','FacundoYoris','Tensión dispara','Fases del alternador en estado óptimo.','2024-02-27T07:21',12.576,0,'2024-02-26T18:47','Tensión generada'),(116,'Programada','Inspección visual y limpieza','2024-04-05T11:30','Grupo electrógeno','Cesar Correia','En proceso','Media','FacundoYoris','Rotura, agrietamiento','',NULL,NULL,720,'2024-03-06T11:31','Carcaza'),(118,'Programada','Termografía y lubricar nuevamente.','2024-09-09T06:51','Grupo electrógeno','Facundo Yoris','Pendiente','Alta','FacundoYoris','Vibraciones.','',NULL,NULL,4500,'2024-02-26T18:47','Rodamientos'),(119,'Programada','Limpiar el tubo de drenaje de condensado.','2024-03-31T16:00','Grupo electrógeno','Cesar Correia','Pendiente','Baja','FacundoYoris','Obstrucción del tubo de drenaje.','',NULL,NULL,250,NULL,'Tubos de drenaje de condensado'),(120,'Programada','Verificar nivel de combustible, mangueras, tubos y alrededores','2024-06-04T18:00','Grupo electrógeno','Nahuel Nuñez','Pendiente','Alta','FacundoYoris','Fuga de combustible','',NULL,NULL,336,NULL,'Combustible'),(121,'Programada','Filtrar combustible, verificar estado del filtro.','2025-01-01T16:00','Grupo electrógeno','Facundo Yoris','En proceso','Alta','FacundoYoris','Contaminación.','',NULL,NULL,8760,'2024-02-28T08:03','Combustible'),(122,'Programada','Verificar que la velocidad se mantenga en valores nominales','2024-02-23T22:00','Grupo electrógeno','Facundo Yoris','Pendiente','Media','FacundoYoris','Desviación de la velocidad.\r\n',NULL,NULL,NULL,8,NULL,'Gobernador de velocidad electrónico'),(123,'Correctiva','Verificar nivel de electrolitos, cargador de batería, cables de batería.','2024-04-10T20:45','Grupo electrógeno','Facundo Yoris','Pendiente','Alta','FacundoYoris','Baja carga de la batería.','',NULL,NULL,0,NULL,'Batería'),(124,'Programada','Verificar nivel de aceite, estado de mangueras, tubos y posibles fugas en alrededores .','2025-03-03T16:00','Grupo electrógeno','Facundo Yoris','Pendiente','Alta','FacundoYoris','Faltante de aceite','',NULL,NULL,288,NULL,'Aceite'),(125,'Programada','Termografía en la zona del brazo basculante y barra transversal','2024-03-16T17:00','Grupo electrógeno','Cesar Correia','Pendiente','Media','FacundoYoris','Calentamiento por fricción entre brazo basculante y barra transversal','',NULL,NULL,4370,NULL,'Brazo basculante y barra transversal'),(126,'Correctiva','Correctiva 1','2022-02-22T16:00','Grupo electrógeno','Correctiva 1','Pendiente','Alta','x','Correctiva 1','',NULL,NULL,0,NULL,'Correctiva 1');
/*!40000 ALTER TABLE `orden_trabajo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ot_programada_finalizada`
--

DROP TABLE IF EXISTS `ot_programada_finalizada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ot_programada_finalizada` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_orden_programada` int DEFAULT NULL,
  `fecha_fin` varchar(45) DEFAULT NULL,
  `fecha_inicio` varchar(45) DEFAULT NULL,
  `observacion` varchar(45) DEFAULT NULL,
  `fecha_inicio_real` varchar(45) DEFAULT NULL,
  `horas_totales` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ot_programada_finalizada`
--

LOCK TABLES `ot_programada_finalizada` WRITE;
/*!40000 ALTER TABLE `ot_programada_finalizada` DISABLE KEYS */;
INSERT INTO `ot_programada_finalizada` VALUES (12,107,'2024-02-26T09:19','2024-02-28T09:19','q',NULL,0.24293),(13,107,'2024-02-26T09:31','2024-02-28T09:31','8','2024-02-26T09:28',0.0594542),(14,107,'2024-02-26T09:38','2024-02-28T09:38','f','2024-02-26T09:37',0.026005),(15,107,'2024-02-26T11:18','2024-02-28T11:18','3','2024-02-26T11:00',0.303073),(16,107,'2024-02-26T16:20','2024-02-28T16:20','7','2024-02-26T11:19',5.01789),(17,107,'2024-02-26T16:32','2024-02-28T16:32','q','2024-02-26T16:25',0.121908),(18,118,'2024-03-05T18:51','2024-09-09T06:51','x','2024-02-26T18:47',192.077),(19,116,'2024-03-06T11:30','2024-04-05T11:30','X','2024-02-26T18:47',208.727);
/*!40000 ALTER TABLE `ot_programada_finalizada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock` (
  `idstock` int NOT NULL AUTO_INCREMENT,
  `item` varchar(75) NOT NULL DEFAULT '',
  `cantidad` int DEFAULT '0',
  `CantidadAdvertencia` int DEFAULT '0',
  `CantidadCritica` int DEFAULT '0',
  PRIMARY KEY (`idstock`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Tabla para administrar el stock de la empresa';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock`
--

LOCK TABLES `stock` WRITE;
/*!40000 ALTER TABLE `stock` DISABLE KEYS */;
INSERT INTO `stock` VALUES (1,'Rodamiento XG-600',0,2,1),(2,'Correa de distribución',1,1,2),(3,'Pistón',0,2,1),(4,'Filtro de aceite',2,3,2),(6,'Bulón',2,5,3),(7,'Bulón rx50',4,2,0),(8,'Bulón rx25',3,1,0),(9,'Biela enteriza',2,1,0),(10,'Biela aligerada',0,2,1),(11,'Aceite f600',1,1,0),(12,'Bulón rx75',0,2,1),(13,'Rodamiento xxxxxxx',2,0,0);
/*!40000 ALTER TABLE `stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terceros`
--

DROP TABLE IF EXISTS `terceros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `terceros` (
  `idterceros` int NOT NULL AUTO_INCREMENT,
  `rol` varchar(45) DEFAULT NULL,
  `numero_telefonico` varchar(15) DEFAULT NULL COMMENT 'asd',
  `correo_electronico` varchar(100) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idterceros`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Tabla que contiene los contactos externos a la empresa como lo puede ser un  proveedor.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terceros`
--

LOCK TABLES `terceros` WRITE;
/*!40000 ALTER TABLE `terceros` DISABLE KEYS */;
INSERT INTO `terceros` VALUES (3,'Servicio','3482534964','javiyoris73@gmail.com','Javier','Yoris','Servicio de soporte técnico'),(6,'Proveedor','03482655054','yorisfacundo@gmail.com','Facu','Yoris','Proveedor de X producto'),(7,'Servicio','3426 151994','comercial@innwayingenieria.com','Innway ','Ingeniería','Programas de mantenimiento'),(8,'Servicio','3435323176','mateopaterno@gmail.com','Mateo','Paterno','Servicio de marketing digital');
/*!40000 ALTER TABLE `terceros` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `usuario` varchar(45) NOT NULL,
  `contraseña` varchar(45) NOT NULL,
  `privilegio` int NOT NULL COMMENT '0 no tiene privilegios\n1 tiene privilegios.\nPrivilegios: Poder ver la función gestión de mantenimiento',
  `nombre` varchar(45) DEFAULT NULL,
  `apellido` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Destinada al login';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('a','a',0,'aa','bb'),('FacundoYoris','42530953',1,'Facundo','Yoris'),('x','x',1,'xx','yy');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-12 11:13:06
